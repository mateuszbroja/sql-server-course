DROP TABLE IF EXISTS [orders];
GO
DROP TABLE IF EXISTS [categories];
GO
DROP TABLE IF EXISTS [customers];
GO
DROP TABLE IF EXISTS [customer_addresses];
GO
DROP TABLE IF EXISTS [employees];
GO
DROP TABLE IF EXISTS [order_items];
GO
DROP TABLE IF EXISTS [product_discounts];
GO
DROP TABLE IF EXISTS [product_inventories];
GO
DROP TABLE IF EXISTS [products];
GO
DROP TABLE IF EXISTS [stores];
GO
